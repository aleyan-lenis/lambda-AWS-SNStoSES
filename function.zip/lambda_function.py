import os
import json
import logging
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# --- Configuración ---
ENDPOINT = os.getenv("FORWARD_ENDPOINT", "https://endpoint.com/recibir")
TIMEOUT = float(os.getenv("HTTP_TIMEOUT", "4"))  # segundos

# Reintentos y pool reusables entre invocaciones (mejor performance en Lambda)
session = requests.Session()
retries = Retry(
    total=3,
    backoff_factor=0.3,
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=frozenset(["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"])
)
adapter = HTTPAdapter(max_retries=retries, pool_connections=10, pool_maxsize=10)
session.mount("https://", adapter)
session.mount("http://", adapter)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def _build_payload_from_sns(sns_record: dict) -> dict:
    # Algunas claves cambian mayúsculas en SNS; cubrimos ambas variantes
    signing_cert = sns_record.get("SigningCertUrl") or sns_record.get("SigningCertURL", "")
    unsubscribe_url = sns_record.get("UnsubscribeUrl") or sns_record.get("UnsubscribeURL", "")

    payload = {
        "Type": sns_record.get("Type", "Notification"),
        "MessageId": sns_record.get("MessageId", ""),
        "TopicArn": sns_record.get("TopicArn", ""),
        "Subject": sns_record.get("Subject", "Amazon SES Email Event Notification"),
        "Message": sns_record.get("Message", ""),
        "Timestamp": sns_record.get("Timestamp", ""),
        "SignatureVersion": sns_record.get("SignatureVersion", "1"),
        "Signature": sns_record.get("Signature", ""),
        "SigningCertURL": signing_cert,
        "UnsubscribeURL": unsubscribe_url,
        # Extra opcional útil para depurar
        "MessageAttributes": sns_record.get("MessageAttributes", {}),
        "SubscriptionArn": sns_record.get("SubscriptionArn", "")
    }
    return payload

def lambda_handler(event, context):
    """
    Trigger: SNS
    Procesa 1..N Records y reenvía cada una al ENDPOINT vía HTTP POST (JSON).
    """
    records = event.get("Records", [])
    if not records:
        logger.warning("Evento sin Records")
        return {"statusCode": 400, "body": json.dumps({"ok": False, "error": "No Records"})}

    results = []
    failures = 0

    for i, rec in enumerate(records):
        sns = rec.get("Sns", {})
        payload = _build_payload_from_sns(sns)

        try:
            resp = session.post(ENDPOINT, json=payload, timeout=TIMEOUT)
            status = resp.status_code
            ok = 200 <= status < 300
            if not ok:
                failures += 1
                logger.warning("POST no-2xx para record %s: status=%s body=%s", i, status, resp.text[:500])
            else:
                logger.info("POST OK record %s: status=%s", i, status)

            results.append({
                "index": i,
                "statusCode": status,
                "responseBody": (resp.text[:1000] if resp.text else "")
            })

        except requests.RequestException as e:
            failures += 1
            logger.exception("Error enviando record %s: %s", i, str(e))
            results.append({
                "index": i,
                "statusCode": 599,
                "error": str(e)
            })

    # SNS no usa la respuesta, pero devolvemos resumen útil
    status_code = 200 if failures == 0 else 207  # 207 Multi-Status si hubo mezclas OK/falla
    return {
        "statusCode": status_code,
        "body": json.dumps({
            "ok": failures == 0,
            "forwardEndpoint": ENDPOINT,
            "processed": len(records),
            "failures": failures,
            "results": results
        })
    }
